# serverless-localstack-lambda-apigateway
Serverless LocalStack Lambda API Gateway
